package br.com.wises.database;

import br.com.wises.database.pojo.Reserva;
import br.com.wises.database.pojo.Organizacao;
import br.com.wises.database.pojo.Sala;
import br.com.wises.database.pojo.Colaborador;
import java.util.List;
import javax.persistence.NoResultException;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;

public class DbAccessor {

    public DbAccessor() {

    }

    public static Colaborador getColaboradorByEmailColaborador(String emailColaborador) {
        try {
            return (Colaborador) EManager.getInstance().createNamedQuery("Colaborador.findByEmailColaborador").setParameter("emailColaborador", emailColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static Colaborador getColaboradorByIdColaborador(int idColaborador) {
        try {
            return (Colaborador) EManager.getInstance().createNamedQuery("Colaborador.findByIdColaborador").setParameter("idColaborador", idColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Sala> getSalaByIdSala(String nomeSala) {
        try {
            return EManager.getInstance().createNamedQuery("Sala.findByNomeSala").setParameter("nomeSala", nomeSala).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static Colaborador getColaboradorByEmailAndSenha(String emailColaborador, String senhaColaborador) {
        try {
            return (Colaborador) EManager.getInstance().createNamedQuery("Colaborador.findByEmailColaboradorAndSenhaColaborador").setParameter("emailColaborador", emailColaborador).setParameter("senhaColaborador", senhaColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static Organizacao getOrganizacaoById(int idOrganizacao) {
        try {
            return (Organizacao) EManager.getInstance().createNamedQuery("Organizacao.findById").setParameter("idOrganizacao", idOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static Organizacao getOrganizacaoByDominio(String dominioOrganizacao) {
        try {
            return (Organizacao) EManager.getInstance().createNamedQuery("Organizacao.findDominioLike").setParameter("dominioOrganizacao", dominioOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Organizacao> getOrganizacoesByDominio(String dominioOrganizacao) {
        try {
            return EManager.getInstance().createNamedQuery("Organizacao.findDominioLike").setParameter("dominioOrganizacao", dominioOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Sala> getSalasByOrganizacaoId(int idOrganizacao) {
        try {
            return EManager.getInstance().createNamedQuery("Sala.findByOrganizacaoId").setParameter("idOrganizacao", idOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Reserva> getReservasByIdSala(int idSala) {
        try {
            return EManager.getInstance().createNamedQuery("Reserva.findByIdSala").setParameter("idSala", idSala).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Reserva> getReservasByIdColaboradorSala(int idColaborador, int idSala) {
        try {
            return EManager.getInstance().createNamedQuery("Reserva.findByIdColaboradorSala").setParameter("idSala", idSala).setParameter("idColaborador", idColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static List<Reserva> getReservasByIdColaborador(int idColaborador) {
        try {
            return EManager.getInstance().createNamedQuery("Reserva.findByIdColaborador").setParameter("idColaborador", idColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public static synchronized void deleteById(int idReserva) {
        try {

            EManager.getInstance().getTransaction().begin();
            Reserva reserva = (Reserva) EManager.getInstance().createNamedQuery("Reserva.findByIdReserva").setParameter("idReserva", idReserva).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
            EManager.getInstance().remove(reserva);
            EManager.getInstance().getTransaction().commit();

        } catch (Exception e) {
            if (EManager.getInstance().getTransaction().isActive()) {
                EManager.getInstance().getTransaction().rollback();
                clear();
            }
        }
    }

    public static synchronized void novaReserva(Reserva reserva) {

        try {

            EManager.getInstance().getTransaction().begin();
            EManager.getInstance().persist(reserva);
            EManager.getInstance().getTransaction().commit();

        } catch (Exception e) {
            if (EManager.getInstance().getTransaction().isActive()) {
                EManager.getInstance().getTransaction().rollback();
                clear();
            }
        }
    }

    public static synchronized void novoColaborador(Colaborador colaborador) {
        try {
            EManager.getInstance().getTransaction().begin();
            EManager.getInstance().persist(colaborador);
            EManager.getInstance().getTransaction().commit();
        } catch (Exception e) {
            if (EManager.getInstance().getTransaction().isActive()) {
                EManager.getInstance().getTransaction().rollback();
                clear();
            }
        }
    }
//
//    public static void modificaColaborador(Colaborador colaborador) {
//        synchronized (this.operationLock) {
//            EManager.getInstance().getTransaction().begin();
//            EManager.getInstance().merge(colaborador);
//            EManager.getInstance().getTransaction().commit();
//        }
//    }
//
//    public static void excluirColaborador(Colaborador colaborador) {
//        synchronized (this.operationLock) {
//            EManager.getInstance().getTransaction().begin();
//            EManager.getInstance().remove(colaborador);
//            EManager.getInstance().getTransaction().commit();
//        }
//    }

    public static void clear() {
        EManager.getInstance().clear();
    }

}
