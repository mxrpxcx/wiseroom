package br.com.wises.database;

import br.com.wises.database.pojo.Reserva;
import br.com.wises.database.pojo.Organizacao;
import br.com.wises.database.pojo.Sala;
import br.com.wises.database.pojo.Colaborador;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;

public class DbAccessor {

    private final EntityManager manager;
    private final Object operationLock;

    public DbAccessor(EntityManager manager, Object operationLock) {
        this.manager = manager;
        this.operationLock = operationLock;
    }

    public Colaborador getColaboradorByEmailColaborador(String emailColaborador) {
        try {
            return (Colaborador) this.manager.createNamedQuery("Colaborador.findByEmailColaborador").setParameter("emailColaborador", emailColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
    
        public Colaborador getColaboradorByIdColaborador(int idColaborador) {
        try {
            return (Colaborador) this.manager.createNamedQuery("Colaborador.findByIdColaborador").setParameter("idColaborador", idColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
        
         public Sala getSalaByIdSala(int idSala) {
        try {
            return (Sala) this.manager.createNamedQuery("Sala.findByIdSala").setParameter("idSala", idSala).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    } 

    public Colaborador getColaboradorByEmailAndSenha(String emailColaborador, String senhaColaborador) {
        try {
            return (Colaborador) this.manager.createNamedQuery("Colaborador.findByEmailColaboradorAndSenhaColaborador").setParameter("emailColaborador", emailColaborador).setParameter("senhaColaborador", senhaColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public Organizacao getOrganizacaoById(int idOrganizacao) {
        try {
            return (Organizacao) this.manager.createNamedQuery("Organizacao.findById").setParameter("idOrganizacao", idOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public Organizacao getOrganizacaoByDominio(String dominioOrganizacao) {
        try {
            return (Organizacao) this.manager.createNamedQuery("Organizacao.findDominioLike").setParameter("dominioOrganizacao", dominioOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<Organizacao> getOrganizacoesByDominio(String dominioOrganizacao) {
        try {
            return this.manager.createNamedQuery("Organizacao.findDominioLike").setParameter("dominioOrganizacao", dominioOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<Sala> getSalasByOrganizacaoId(int idOrganizacao) {
        try {
            return this.manager.createNamedQuery("Sala.findByOrganizacaoId").setParameter("idOrganizacao", idOrganizacao).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<Reserva> getReservasByIdSala(int idSala) {
        try {
            return this.manager.createNamedQuery("Reserva.findByIdSala").setParameter("idSala", idSala).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<Reserva> getReservasByIdColaborador(int idColaborador) {
        try {
            return this.manager.createNamedQuery("Reserva.findByIdColaborador").setParameter("idColaborador", idColaborador).setHint(QueryHints.REFRESH, HintValues.TRUE).getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    public void novaReserva(Reserva reserva) {
        synchronized (this.operationLock) {
            this.manager.getTransaction().begin();
            this.manager.persist(reserva);
            this.manager.getTransaction().commit();
        }
    }

    public void novoColaborador(Colaborador colaborador) {
        synchronized (this.operationLock) {
            this.manager.getTransaction().begin();
            this.manager.persist(colaborador);
            this.manager.getTransaction().commit();
        }
    }
//
//    public void modificaColaborador(Colaborador colaborador) {
//        synchronized (this.operationLock) {
//            this.manager.getTransaction().begin();
//            this.manager.merge(colaborador);
//            this.manager.getTransaction().commit();
//        }
//    }
//
//    public void excluirColaborador(Colaborador colaborador) {
//        synchronized (this.operationLock) {
//            this.manager.getTransaction().begin();
//            this.manager.remove(colaborador);
//            this.manager.getTransaction().commit();
//        }
//    }
}
