/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.wises.database.pojo;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author fsw
 */
@Entity
@Table(name = "tbcolaborador")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Colaborador.findAll", query = "SELECT c FROM Colaborador c"),
    @NamedQuery(name = "Colaborador.findByIdColaborador", query = "SELECT c FROM Colaborador c WHERE c.idColaborador = :idColaborador"),
    @NamedQuery(name = "Colaborador.findByNomeColaborador", query = "SELECT c FROM Colaborador c WHERE c.nomeColaborador = :nomeColaborador"),
    @NamedQuery(name = "Colaborador.findByEmailColaboradorAndSenhaColaborador", query = "SELECT c FROM Colaborador c WHERE c.emailColaborador = :emailColaborador AND c.senhaColaborador = :senhaColaborador"),
    @NamedQuery(name = "Colaborador.findByEmailColaborador", query = "SELECT c FROM Colaborador c WHERE c.emailColaborador = :emailColaborador"),
    @NamedQuery(name = "Colaborador.findByAdministrador", query = "SELECT c FROM Colaborador c WHERE c.administrador = :administrador"),
    @NamedQuery(name = "Colaborador.findBySenhaColaborador", query = "SELECT c FROM Colaborador c WHERE c.senhaColaborador = :senhaColaborador")})

public class Colaborador implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idColaborador")
    private Integer idColaborador;
    
    
    @Size(max = 100)
    @Column(name = "nomeColaborador")
    private String nomeColaborador;
    
    
    @Size(max = 100)
    @Column(name = "emailColaborador")
    private String emailColaborador;
    
    
    @Column(name = "administrador")
    private Boolean administrador;
    
    
    @Size(max = 128)
    @Column(name = "senhaColaborador")
    private String senhaColaborador;
    
    
//   @OneToMany(mappedBy = "idColaboradorReserva")
//    private Collection<Reserva> reservaCollection;
    
    
    @JoinColumn(name = "idOrganizacao", referencedColumnName = "idOrganizacao")
    @ManyToOne
    private Organizacao idOrganizacao;
    
    public Colaborador() {
    }

    public Colaborador(Integer idColaborador) {
        this.idColaborador = idColaborador;
    }

    public Integer getIdColaborador() {
        return idColaborador;
    }

    public void setIdColaborador(Integer idColaborador) {
        this.idColaborador = idColaborador;
    }

    public String getNomeColaborador() {
        return nomeColaborador;
    }

    public void setNomeColaborador(String nomeColaborador) {
        this.nomeColaborador = nomeColaborador;
    }

    public String getEmailColaborador() {
        return emailColaborador;
    }

    public void setEmailColaborador(String emailColaborador) {
        this.emailColaborador = emailColaborador;
    }

    public Boolean getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Boolean administrador) {
        this.administrador = administrador;
    }

    public String getSenhaColaborador() {
        return senhaColaborador;
    }

    public void setSenhaColaborador(String senhaColaborador) {
        this.senhaColaborador = senhaColaborador;
    }

 //  @XmlTransient
 //   public Collection<Reserva> getReservaCollection() {
 //       return reservaCollection;
 //   }

 //   public void setReservaCollection(Collection<Reserva> reservaCollection) {
 //       this.reservaCollection = reservaCollection;
 //   }

    public Organizacao getIdOrganizacao() {
        return idOrganizacao;
    }

    public void setIdOrganizacao(Organizacao idOrganizacao) {
        this.idOrganizacao = idOrganizacao;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idColaborador != null ? idColaborador.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Colaborador)) {
            return false;
        }
        Colaborador other = (Colaborador) object;
        if ((this.idColaborador == null && other.idColaborador != null) || (this.idColaborador != null && !this.idColaborador.equals(other.idColaborador))) {
            return false;
        }
        return true;
    }

//  @Override
//    public String toString() {
//       return "Colaborador{" + "idColaborador=" + idColaborador + ", nomeColaborador=" + nomeColaborador + ", emailColaborador=" + emailColaborador + ", administrador=" + administrador + ", senhaColaborador=" + senhaColaborador + ", reservaCollection=" + reservaCollection + ", idOrganizacao=" + idOrganizacao + '}';
//   }

   
    
}
