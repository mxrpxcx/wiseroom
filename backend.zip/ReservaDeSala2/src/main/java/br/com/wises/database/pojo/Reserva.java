/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.wises.database.pojo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author fsw
 */
@Entity
@Table(name = "tbreserva")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reserva.findAll", query = "SELECT r FROM Reserva r"),
    @NamedQuery(name = "Reserva.findByIdReserva", query = "SELECT r FROM Reserva r WHERE r.idReserva = :idReserva"),
    @NamedQuery(name = "Reserva.findByIdSala", query = "SELECT r FROM Reserva r WHERE r.idSalaReserva = :idSala"),
    @NamedQuery(name = "Reserva.findByIdColaboradorSala", query = "SELECT r FROM Reserva r WHERE r.idSalaReserva = :idSala AND r.idColaboradorReserva = :idColaborador"),
    @NamedQuery(name = "Reserva.findByDescricaoReserva", query = "SELECT r FROM Reserva r WHERE r.descricaoReserva = :descricaoReserva"),
    @NamedQuery(name = "Reserva.findByDataReserva", query = "SELECT r FROM Reserva r WHERE r.dataReserva = :dataReserva"),
    @NamedQuery(name = "Reserva.findByHoraInicioReserva", query = "SELECT r FROM Reserva r WHERE r.horaInicioReserva = :horaInicioReserva"),
    @NamedQuery(name = "Reserva.findByHoraFimReserva", query = "SELECT r FROM Reserva r WHERE r.horaFimReserva = :horaFimReserva")})
public class Reserva implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idReserva")
    private Integer idReserva;
    
    
    @Size(max = 500)
    @Column(name = "descricaoReserva")
    private String descricaoReserva;
    
    
    @Size(max = 12)
    @Column(name = "dataReserva")
    private String dataReserva;
    
    
    @Size(max = 6)
    @Column(name = "horaInicioReserva")
    private String horaInicioReserva;
    
    
    @Size(max = 6)
    @Column(name = "horaFimReserva")
    private String horaFimReserva;
    
    
  //  @JoinColumn(name = "idColaboradorReserva", referencedColumnName = "idColaborador")
  ///  @ManyToOne
  //  private Colaborador idColaboradorReserva;
     @Column(name = "idColaboradorReserva")
    private Integer idColaboradorReserva;
    
 //   @JoinColumn(name = "idSalaReserva", referencedColumnName = "idSala")
  //  @ManyToOne
  //  private Sala SalaReserva;

    @Column(name = "idSalaReserva")
    private Integer idSalaReserva;
    
     @Column(name = "nomeColaborador")
    private String nomeColaborador;
    
    public Reserva() {
    }

    public Reserva(Integer idReserva) {
        this.idReserva = idReserva;
    }

    public Integer getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(Integer idReserva) {
        this.idReserva = idReserva;
    }

    public String getDescricaoReserva() {
        return descricaoReserva;
    }

    public void setDescricaoReserva(String descricaoReserva) {
        this.descricaoReserva = descricaoReserva;
    }

    public String getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(String dataReserva) {
        this.dataReserva = dataReserva;
    }

    public String getNomeColaborador() {
        return nomeColaborador;
    }

    public void setNomeColaborador(String nomeColaborador) {
        this.nomeColaborador = nomeColaborador;
    }
    
    public String getHoraInicioReserva() {
        return horaInicioReserva;
    }

    public void setHoraInicioReserva(String horaInicioReserva) {
        this.horaInicioReserva = horaInicioReserva;
    }

    public String getHoraFimReserva() {
        return horaFimReserva;
    }

    public void setHoraFimReserva(String horaFimReserva) {
        this.horaFimReserva = horaFimReserva;
    }

    public Integer getIdColaboradorReserva() {
        return idColaboradorReserva;
    }

    public void setIdColaboradorReserva(Integer idColaboradorReserva) {
        this.idColaboradorReserva = idColaboradorReserva;
    }

    public Integer getIdSalaReserva() {
        return idSalaReserva;
    }

    public void setIdSalaReserva(Integer idSalaReserva) {
        this.idSalaReserva = idSalaReserva;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idReserva != null ? idReserva.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reserva)) {
            return false;
        }
        Reserva other = (Reserva) object;
        if ((this.idReserva == null && other.idReserva != null) || (this.idReserva != null && !this.idReserva.equals(other.idReserva))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.wises.database.pojo.Reserva[ idReserva=" + idReserva + " ]";
    }
    
}
