/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.wises.database.pojo;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author fsw
 */
@Entity
@Table(name = "tbsala")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sala.findAll", query = "SELECT s FROM Sala s"),
    @NamedQuery(name = "Sala.findByIdSala", query = "SELECT s FROM Sala s WHERE s.idSala = :idSala"),
    @NamedQuery(name = "Sala.findByNomeSala", query = "SELECT s FROM Sala s WHERE s.nomeSala = :nomeSala"),
    @NamedQuery(name = "Sala.findByCapacidadeSala", query = "SELECT s FROM Sala s WHERE s.capacidadeSala = :capacidadeSala"),
    @NamedQuery(name = "Sala.findByAreaSala", query = "SELECT s FROM Sala s WHERE s.areaSala = :areaSala"),
    @NamedQuery(name = "Sala.findByDescricaoSala", query = "SELECT s FROM Sala s WHERE s.descricaoSala = :descricaoSala")})
public class Sala implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "idSala")
    private Integer idSala;
    @Size(max = 100)
    @Column(name = "nomeSala")
    private String nomeSala;
    @Column(name = "capacidadeSala")
    private Integer capacidadeSala;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "areaSala")
    private Float areaSala;
    @Size(max = 500)
    @Column(name = "descricaoSala")
    private String descricaoSala;
  
 //   @OneToMany(mappedBy = "idSalaReserva")
 //   private Collection<Reserva> reservaCollection;
 //   @JoinColumn(name = "idOrganizacao", referencedColumnName = "idOrganizacao")
 //   @ManyToOne
 //   private Organizacao idOrganizacao; 

    public Sala() {
    }

    public Sala(Integer idSala) {
        this.idSala = idSala;
    }

    public Integer getIdSala() {
        return idSala;
    }

    public void setIdSala(Integer idSala) {
        this.idSala = idSala;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    public Integer getCapacidadeSala() {
        return capacidadeSala;
    }

    public void setCapacidadeSala(Integer capacidadeSala) {
        this.capacidadeSala = capacidadeSala;
    }

    public Float getAreaSala() {
        return areaSala;
    }

    public void setAreaSala(Float areaSala) {
        this.areaSala = areaSala;
    }

    public String getDescricaoSala() {
        return descricaoSala;
    }

    public void setDescricaoSala(String descricaoSala) {
        this.descricaoSala = descricaoSala;
    }

    
 //   @XmlTransient
  //  public Collection<Reserva> getReservaCollection() {
  //      return reservaCollection;
  //  }

 //   public void setReservaCollection(Collection<Reserva> reservaCollection) {
  //      this.reservaCollection = reservaCollection;
  //  }

  //  public Organizacao getIdOrganizacao() {
  //      return idOrganizacao;
  //  }

 ///   public void setIdOrganizacao(Organizacao idOrganizacao) {
  //      this.idOrganizacao = idOrganizacao;
   // } 

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSala != null ? idSala.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sala)) {
            return false;
        }
        Sala other = (Sala) object;
        if ((this.idSala == null && other.idSala != null) || (this.idSala != null && !this.idSala.equals(other.idSala))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.wises.database.pojo.Sala[ idSala=" + idSala + " ]";
    }
    
}
