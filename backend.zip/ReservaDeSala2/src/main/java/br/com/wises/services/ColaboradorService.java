package br.com.wises.services;

import br.com.wises.database.EManager;
import br.com.wises.database.pojo.Organizacao;
import br.com.wises.database.pojo.Colaborador;
import com.google.gson.Gson;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.List;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import org.json.JSONArray;
import org.json.JSONObject;

@Path("colaborador")
public class ColaboradorService {

// Esse aqui fica só de exemplo pra mostrar como faz pra pegar o parâmetro pelo path do request
//    @GET
//    @Path("/{email}")
//    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
//    public Colaborador getUserJson(
//            @PathParam("email") String email,
//            @HeaderParam("authorization") String authorization) {
//        if (authorization != null && authorization.equals("secret")) {
//            Colaborador user = EManager.getInstance().getDbAccessor().getUserByEmail(email);
//            if (user != null) {
//                user.getIdOrganizacao().setColaboradorCollection(null);
//                user.getIdOrganizacao().setSalaCollection(null);
//                user.setSenha(null);
//                return user;
//            }
//        } else {
//            return null;
//        }
//        return null;
//    }
    @GET
    @Path("getByEmail")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Colaborador getUserByEmailJson(
            @HeaderParam("emailColaborador") String emailColaborador,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            Colaborador colaborador = EManager.getInstance().getDbAccessor().getColaboradorByEmailColaborador(emailColaborador);
            if (colaborador != null) {
                colaborador.setSenhaColaborador(null);
                return colaborador;
            }
        } else {
            return null;
        }
        return null;
    }

    @GET
    @Path("login")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public String authentication(
            @HeaderParam("emailColaborador") String emailColaborador,
            @HeaderParam("senhaColaborador") String senhaColaborador,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            System.out.println(emailColaborador+"  "+senhaColaborador);
            Colaborador colaborador = EManager.getInstance().getDbAccessor().getColaboradorByEmailAndSenha(emailColaborador, senhaColaborador);
            Gson gson = new Gson();

            if (colaborador != null) {
                return gson.toJson(colaborador);
            } else {

                return "error 1"+"auth"+authorization+" "+emailColaborador;
            }
        } else {
            return "error 2"+"auth"+authorization+" "+emailColaborador;
        }
    }

    @GET
    @Path("loginV2")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Colaborador authenticationV2(
            @HeaderParam("emailColaborador") String emailColaborador,
            @HeaderParam("senhaColaborador") String senhaColaborador,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            Colaborador colaborador = EManager.getInstance().getDbAccessor().getColaboradorByEmailAndSenha(emailColaborador, senhaColaborador);
            if (colaborador != null) {
               
                colaborador.setSenhaColaborador(null);
                return colaborador;
            }
        } else {
            return null;
        }
        return null;
    }

    @POST
    @Path("cadastro")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public String cadastrarColaborador(
            @HeaderParam("authorization") String authorization,
            @HeaderParam("novoColaborador") String novoColaboradorEncoded) {
        if (authorization != null && authorization.equals("secret")) {
            try {
                //String userEncodedOk = "ewogICAgImVtYWlsIjogInJvZHJpZ28ucXVpc2VuQHdpc2VzLmNvbS5iciIsCiAgICAibm9tZSI6ICJSb2RyaWdvIFF1aXNlbiAzIiwKICAgICJzZW5oYSI6ICIxMjMiCn0=";
                //String userEncodedNotOk = "ewogICAgImVtYWlsIjogInJvZHJpZ28ucXVpc2VuQHdpc2UuY29tLmJyIiwKICAgICJub21lIjogIlJvZHJpZ28gUXVpc2VuIDUiLAogICAgInNlbmhhIjogIjEyMyIKfQ==";
                String userDecoded = new String(Base64.getDecoder().decode(novoColaboradorEncoded.getBytes()), Charset.forName("UTF-8"));

                JSONObject userObj = new JSONObject(userDecoded);
                Colaborador novoColaborador = new Colaborador();
                String emailColaborador, nomeColaborador, senhaColaborador;
                Boolean administrador;
                String dominio = null;
                int idOrganizacao = 0;

                if (userObj.has("emailColaborador") && userObj.has("nomeColaborador") && userObj.has("senhaColaborador")) {
                    emailColaborador = userObj.getString("emailColaborador");
                    nomeColaborador = userObj.getString("nomeColaborador");
                    senhaColaborador = userObj.getString("senhaColaborador");
                    administrador = userObj.getBoolean("administrador");

                    if (emailColaborador.isEmpty() || nomeColaborador.isEmpty() || senhaColaborador.isEmpty()) {
                        return "Erro ao criar conta, os dados enviados estão incompletos 1";
                    } else if (emailColaborador.contains("@")) {
                        dominio = emailColaborador.split("@")[1];
                    }
                } else {
                    return "Erro ao criar conta, os dados enviados estão incompletos 2";
                }

                if (EManager.getInstance().getDbAccessor().getColaboradorByEmailColaborador(emailColaborador) != null) {
                    return "O email informado já está cadastrado";
                }

             //   Organizacao organizacao = new Organizacao();
            //    try {
            //        organizacao = EManager.getInstance().getDbAccessor().getOrganizacaoById(idOrganizacao);
            //        if (organizacao == null) {
              //          return "Erro ao cadastrar usuário, a organização informada não existe";
             //       }
            //    } catch (Exception e) {
             //       return "Erro ao criar conta, os dados enviados estão incompletos 3";
            //    }

                novoColaborador.setEmailColaborador(emailColaborador);
                novoColaborador.setNomeColaborador(nomeColaborador);
                novoColaborador.setSenhaColaborador(senhaColaborador);
                novoColaborador.setAdministrador(administrador);

                EManager.getInstance().getDbAccessor().novoColaborador(novoColaborador);

                return "Usuário criado com sucesso";
            } catch (Exception e) {

                return String.valueOf(e);
            }

        } else {
            return "Token inválido";
        }
    }
}
