package br.com.wises.services;

import br.com.wises.database.DbAccessor;
import br.com.wises.database.EManager;
import br.com.wises.database.pojo.Reserva;
import br.com.wises.database.pojo.Colaborador;
import com.google.gson.Gson;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import org.json.JSONObject;

@Path("reserva")
public class ReservaService {

    @GET
    @Path("byIdSala")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Reserva> getReservasByIdSala(
            @HeaderParam("idSala") int idSala,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            List<Reserva> lista = DbAccessor.getReservasByIdSala(idSala);
                        
                        
                        System.out.println("asdasdd"+lista.toString());
                        return lista;
                        
                        
                        
        } else {
            return null;
        }
    }
    
    @GET
    @Path("byIdColaboradorSala")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Reserva> getReservasByIdColaboradorSala(
            @HeaderParam("idSala") String idSala,
            @HeaderParam("idColaborador") String idColaborador,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            List<Reserva> lista = DbAccessor.getReservasByIdColaboradorSala(Integer.parseInt(idColaborador), Integer.parseInt(idSala));
                        Gson gson = new Gson();
                        
                        System.out.println("asdasdd"+lista.toString());
                        return lista;
                        
                        
                        
        } else {
            return null;
        }
    }

    @GET
    @Path("ReservaIdSala")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Reserva> getReservasByIdSala(
            @HeaderParam("idSala") String idSala,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            List<Reserva> lista = DbAccessor.getReservasByIdSala(Integer.parseInt(idSala));
            return lista;
        } else {
            return null;
        }
    }
    
    
    @POST
    @Path("deleteById")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public String deleteReservaById(
            @HeaderParam("idReserva") String idReserva,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            DbAccessor.deleteById(Integer.parseInt(idReserva));
            return "Apagado";
        } else {
            return "Nao apagado";
        }
    }

    @POST
    @Path("cadastrar")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public String createReserva(
            @HeaderParam("novaReserva") String novaReservaEncoded,
            @HeaderParam("authorization") String authorization) {
        try {
            if (authorization != null && authorization.equals("secret")) {
                String reservaDecoded = new String(Base64.getDecoder().decode(novaReservaEncoded.getBytes()), Charset.forName("UTF-8"));
                JSONObject reservaObj = new JSONObject(reservaDecoded);
                Reserva novaReserva = new Reserva();
                System.out.println("Reserva Encoded: " + novaReservaEncoded);
                System.out.println("Reserva Decoded: " + reservaDecoded);
                int idSala = 0, idColaborador = 0;
                String descricaoReserva = "";
                String horaInicioReserva = "00:00";
                String horaFimReserva = "00:00";
                String dataReserva = "00-00-0000";
                String nomeColaborador = "Sem colaborador";

                if (reservaObj.has("idSalaReserva") && reservaObj.has("idColaboradorReserva") && reservaObj.has("descricaoReserva") && reservaObj.has("horaInicioReserva") && reservaObj.has("horaFimReserva") && reservaObj.has("dataReserva") && reservaObj.has("nomeColaborador")) {
                    idSala = reservaObj.getInt("idSalaReserva");
                    idColaborador = reservaObj.getInt("idColaboradorReserva");
                    descricaoReserva = reservaObj.getString("descricaoReserva");
                    horaInicioReserva = reservaObj.getString("horaInicioReserva");
                    horaFimReserva = reservaObj.getString("horaFimReserva");
                    dataReserva = reservaObj.getString("dataReserva");
                    nomeColaborador = reservaObj.getString("nomeColaborador");


                    Colaborador colaborador = DbAccessor.getColaboradorByIdColaborador(idColaborador);
                    
                    novaReserva.setIdColaboradorReserva(colaborador.getIdColaborador());
                    
                    novaReserva.setDescricaoReserva(descricaoReserva);
                    novaReserva.setNomeColaborador(nomeColaborador);
                    novaReserva.setHoraInicioReserva(horaInicioReserva);
                    novaReserva.setHoraFimReserva(horaFimReserva);
                    novaReserva.setDataReserva(dataReserva);
                    novaReserva.setIdSalaReserva(idSala);
                    novaReserva.setIdColaboradorReserva(idColaborador);

                  

                    DbAccessor.novaReserva(novaReserva);
                    return "Reserva realizada com sucesso";
                } else {
                    return "A reserva não foi realizada";
                }
            } else {
                return "A reserva não foi realizada";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "A reserva não foi realizada";
        }
    }
}
