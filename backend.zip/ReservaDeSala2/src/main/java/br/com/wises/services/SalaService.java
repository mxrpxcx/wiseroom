package br.com.wises.services;

import br.com.wises.database.DbAccessor;
import br.com.wises.database.EManager;
import br.com.wises.database.pojo.Sala;
import com.google.gson.Gson;
import java.util.List;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("sala")
public class SalaService {

    @GET
    @Path("sala")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Sala> getSalas(
            @HeaderParam("idSala") int idOrganizacao,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            List<Sala> lista = DbAccessor.getSalasByOrganizacaoId(idOrganizacao);
            for (int i = 0; i < lista.size(); i++) {
               
            }
            return lista;
        } else {
            return null;
        }
    }
    
    @GET
    @Path("getSalaByNome")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Sala> getSalaByIdSala(
            @HeaderParam("nomeSala") String nomeSala,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
              List<Sala> lista = DbAccessor.getSalaByIdSala(nomeSala);
              return lista;
        } else {
            return null;
        }
    } 

}
