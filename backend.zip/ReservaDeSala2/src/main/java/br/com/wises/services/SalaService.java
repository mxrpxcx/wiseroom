package br.com.wises.services;

import br.com.wises.database.EManager;
import br.com.wises.database.pojo.Sala;
import com.google.gson.Gson;
import java.util.List;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("sala")
public class SalaService {

    @GET
    @Path("sala")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public List<Sala> getSalas(
            @HeaderParam("idSala") int idOrganizacao,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            List<Sala> lista = EManager.getInstance().getDbAccessor().getSalasByOrganizacaoId(idOrganizacao);
            for (int i = 0; i < lista.size(); i++) {
               
            }
            return lista;
        } else {
            return null;
        }
    }
    
    @GET
    @Path("getSalaId")
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public String getSalaByIdSala(
            @HeaderParam("idSala") String idSala,
            @HeaderParam("authorization") String authorization) {
        if (authorization != null && authorization.equals("secret")) {
            Sala sala = EManager.getInstance().getDbAccessor().getSalaByIdSala(Integer.parseInt(idSala));
            Gson gson = new Gson();
            
            if (sala != null) {
                
                System.out.println(sala.getNomeSala());
                return gson.toJson(sala);
            }
        } else {
            return null;
        }
        return null;
    }

}
